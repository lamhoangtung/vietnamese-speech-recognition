Distributed Library
===================

.. doxygenfile:: DistributedApi.h


Reducer Framework
-----------------

.. doxygenclass:: fl::Reducer
   :members:
   :undoc-members:

Reducers
--------

.. doxygenclass:: fl::InlineReducer
   :members:
   :undoc-members:

.. doxygenclass:: fl::CoalescingReducer
   :members:
   :undoc-members:
